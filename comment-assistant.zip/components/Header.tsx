import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="text-center">
      <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#A8DADC] to-[#F1FAEE]">
        Comment Assistant
      </h1>
      <p className="mt-3 text-lg text-[#A8DADC]/80">
        Generate authentic, valuable comments for LinkedIn posts in seconds.
      </p>
    </header>
  );
};

export default Header;